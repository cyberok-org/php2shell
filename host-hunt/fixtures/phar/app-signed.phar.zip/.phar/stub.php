<?php Phar::mapPhar(); include "phar://" . __FILE__ . "/main.php"; __HALT_COMPILER(); ?>
